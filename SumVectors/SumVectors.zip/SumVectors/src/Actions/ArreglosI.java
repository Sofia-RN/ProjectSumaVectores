package Actions;

//Metodos utilizados en la clase ArreglosImpl
public interface ArreglosI {

    public void insertarLongitudArray();
    public void insertarValorArray();
    public void sumarArreglo();

}
